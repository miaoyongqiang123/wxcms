<?php
/** .-------------------------------------------------------------------
 * |  Software: [HDPHP framework]
 * |      Site: www.hdphp.com  www.hdcms.com
 * |-------------------------------------------------------------------
 * |    Author: 向军 <2300071698@qq.com>
 * |    WeChat: aihoudun
 * | Copyright (c) 2012-2019, www.houdunwang.com. All Rights Reserved.
 * '-------------------------------------------------------------------*/

namespace tests\unit;

use tests\Test;

/**
 * 单元测试
 * Class ExampleTest
 *
 * @package tests\unit
 */
class ExampleTest extends Test
{
    public function setUp()
    {
        parent::setUp();
    }

    public function test_example()
    {
        $this->assertTrue(true);
    }
}