<extend file='resource/view/admin/master'/>
<!--父模板路径-->
<block name="content">
    <ul class="nav nav-tabs" role="tablist">
        <li class="active"><a href="#tab1" role="tab" data-toggle="tab">欢迎页面</a></li>
    </ul>
    <div class="alert alert-info">
        微信cms系统后台登录
    </div>
    <div class="panel panel-default">
        <div class="panel-body">
            <table class="table table-hover">
                <thead>
                <tr>
                    <th>事件</th>
                    <th>描述</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>项目负责人</td>
                    <td>小苗</td>
                </tr>
                <tr>
                    <td>使用框架</td>
                    <td>HDPHP</td>
                </tr>
                <tr>
                    <td>服务器环境</td>
                    <td>apache</td>
                </tr>
                <tr>
                    <td>联系邮箱</td>
                    <td>1143490760@qq.com</td>
                </tr>
                <tr>
                    <td>qq</td>
                    <td>1143490760</td>
                </tr>
                <tr>
                    <td>开发周期</td>
                    <td>30天</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</block>
